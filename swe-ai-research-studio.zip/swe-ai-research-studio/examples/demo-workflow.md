# 演示工作流：从找文献到组会汇报

本文演示 `swe-ai-research-studio` 的链式调用。示例方向：**大语言模型 Agent（LLM Agent）**。

## 1. 检索文献

```text
/lit-search LLM agent planning benchmark
```

得到 3–5 篇文献卡片（含摘要、链接、BibTeX），存入 `lit-*.md`。随后可 `/bib-auto` 校验导出到 `refs-llm-agent.bib`。

## 2. 快速筛选

```text
/paper-quick <其中一篇的 arXiv 链接>
```

得到价值判断（值得精读/泛读/跳过）。

## 3. 深度精读

```text
/paper-deep <论文 PDF>
```

得到固定结构精读笔记 `notes-*.md`（动机、RQ、方法、trade-off、实验、limitation、未来方向）。可配合 `/paper-translate` 翻译关键段落、`/paper-code-map` 映射开源仓库。

## 4. 复现评估

```text
/paper-reproduce <论文 + 代码仓库>
```

得到 `reproduce-checklist.md`（环境、依赖、风险、步骤）。随后可用 `/dataset-find` 补齐数据、`/exp-plan` 设计实验。

## 5. 生成笔记与知识图谱

```text
/note-gen <精读笔记>
/kg-lit <多篇相关论文>
```

得到标准化 Obsidian 笔记与文献知识图谱（`kg-*.md` + Mermaid）。

## 6. 绘图与写作

```text
/fig-prompt 系统架构图，drawio
/paper-outline 目标会议 ICSE
/paper-write 引言章节
/paper-polish <草稿段落>
```

得到架构图 prompt、论文大纲、草稿与润色版本。

## 7. 组会汇报

```text
/note-merge --dir notes/
/note-review
```

合并所有笔记为综述素材，并生成组会汇报 PPT 大纲与讲稿。

## 串行示例

```text
/lit-search LLM agent
→ /paper-quick
→ /paper-deep
→ /note-gen
→ /kg-lit
→ /fig-prompt
→ /note-review
```

每一步输出独立文件，可随时批量导出到 Obsidian 或 Zotero。
