# /dataset-find /exp-plan /exp-analysis — 数据集与实验模块

本指令覆盖 `/dataset-find`（数据集检索）、`/exp-plan`（实验方案设计）、`/exp-analysis`（结果分析）。

## 用途

- `/dataset-find`：检索公开数据集、下载链接、介绍与引用。
- `/exp-plan`：设计实验方案、baseline、消融实验、指标；所有方案标注核验渠道。
- `/exp-analysis`：分析实验结果、表格文字描述、讨论、失败原因分析；不凭空编造数值。

## 输入

- `/dataset-find`：任务类型/领域/数据模态（代码、文本、图、联邦学习等）。
- `/exp-plan`：研究方向 + 方法 + 目标会议/期刊。
- `/exp-analysis`：真实实验结果（用户提供表格/JSON/日志）或论文实验结果。

## 步骤

### /dataset-find

1. 用 `web_search` 检索数据集官网、论文、Hugging Face / Papers With Code 等来源。
2. 输出名称、规模、模态、许可、下载链接、原始引用。

```markdown
## 数据集卡片
| 名称 | 规模 | 模态 | 许可 | 下载链接 | 引用 |
| --- | --- | --- | --- | --- | --- |
```

### /exp-plan

1. 确定 RQ → 指标 → baseline → 数据集 → 消融维度。
2. 每个 baseline/指标/数据集给出来源（论文或官网）。
3. 输出：

```markdown
## 实验方案
## RQ 与指标映射
| RQ | 指标 | 数据集 | 对比方法 |
## Baseline 设计（附来源）
## 消融设计（附维度与理由）
## 可核验渠道
| 项 | 来源链接 |
```

### /exp-analysis

1. 只用用户提供的真实数据；无数据时输出“分析框架 + 待用户提供数据”。
2. 输出：

```markdown
## 结果分析
## 表格描述（基于真实数据）
## 与 baseline 的差异讨论
## 失败/异常原因分析
## 结论与局限
```

## 安全约束（强约束）

- **绝不编造实验数值、指标、消融结果**。`/exp-analysis` 无真实数据时只给框架，不填数。
- 所有方案与数据集必须附可核验来源；无法核验标【待验证】。

## 下一步引导

`/dataset-find` → `/exp-plan` → `/paper-reproduce`；`/exp-analysis` → `/paper-write`（实验章节）。
