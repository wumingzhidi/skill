# /fig-prompt /mermaid-fig — 可视化与绘图

本指令覆盖 `/fig-prompt`（绘图 prompt）与 `/mermaid-fig`（直接输出 Mermaid）。

## 用途

- `/fig-prompt`：生成科研绘图 prompt，用于 drawio、tikz、mermaid、plantuml、visio；架构图、流程图、对比图、框图。
- `/mermaid-fig`：直接输出 Mermaid 代码，用于论文框图、流程图、知识图谱。

## 输入

- 必填：图类型 + 内容要素（组件/流程/关系）。
- 可选：目标工具、论文模板风格要求。

## 步骤

1. 明确图要表达的关系（层级/流程/对比）。
2. 先给结构草案，再输出最终代码或 prompt。
3. Mermaid 代码需语法可渲染（`flowchart`/`graph`/`mindmap` 等），并附节点说明。

## 输出模板（/mermaid-fig）

```mermaid
flowchart TD
    A[输入] --> B[模块1]
    B --> C{判断}
    C -->|是| D[输出]
    C -->|否| B
```

## 输出模板（/fig-prompt）

```markdown
## 图的目标
## 元素清单
| 元素 | 类型（框/箭头/分组） | 标注文字 |
## 给绘图工具的 prompt
（针对 drawio/tikz/plantuml/visio 的完整生成指令）
```

## 安全约束

- 图表只表达用户提供或论文原文可核验的结构，不虚构关系。
- 引用他人架构图需标注来源，不做像素级抄袭。

## 下一步引导

`/fig-prompt` / `/mermaid-fig` → `/paper-latex`（插入论文）。
