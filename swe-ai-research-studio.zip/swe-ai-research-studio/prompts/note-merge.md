# /note-gen /note-merge /note-review — 笔记管理

本指令覆盖 `/note-gen`（生成科研笔记）、`/note-merge`（批量合并）、`/note-review`（组会汇报）。

## 用途

- `/note-gen`：基于论文生成标准化科研笔记，适配 Obsidian/Zotero。
- `/note-merge`：批量合并多篇文献笔记，整理综述素材。
- `/note-review`：组会汇报 PPT 大纲、讲稿、答辩提纲。

## 输入

- `/note-gen`：论文全文或精读笔记。
- `/note-merge`：多篇笔记文件（可用 `scripts/export_markdown.py --dir notes/ --out merged.md` 辅助合并）。
- `/note-review`：多篇笔记 + 汇报对象（组会/开题/答辩）。

## 步骤

### /note-gen

套用 `templates/paper-notes.md.template`，写入标准 frontmatter，标题使用统一命名 `notes-<short-title>.md`。

### /note-merge

1. 汇总各篇笔记的动机/方法/实验/局限。
2. 去重、按主题归类，输出综述素材：

```markdown
# 综述素材合并：<主题>
## 主题一
- 来源：<标题> | 观点：... | 依据：...
## 待补充/矛盾点
```

### /note-review

套用 `templates/meeting-slide-outline.md.template`，输出大纲 + 讲稿要点 + 可能被问的问题。

## 安全约束

- 合并时保留每条的来源，不把多篇内容拼成“无出处原创”。
- 讲稿与结论以笔记为依据，不新增未核验论断。

## 下一步引导

`/note-gen` → `/note-merge` → `/kg-lit` / `/note-review`。
