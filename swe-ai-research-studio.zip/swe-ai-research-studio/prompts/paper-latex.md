# /paper-latex /paper-word-helper /paper-format — LaTeX、Word 与格式标准化

本指令覆盖 `/paper-latex`（LaTeX 生成/修改/调试）、`/paper-word-helper`（Word 结构化内容）、`/paper-format`（会议/期刊格式标准化）。

## 用途

- `/paper-latex`：生成、修改、调试 LaTeX，输出表格、公式、算法伪代码。
- `/paper-word-helper`：生成适合 Word 排版的结构化 Markdown/文本。
- `/paper-format`：按目标会议/期刊模板要求规范字体、段落、参考文献格式。

## 输入

- 必填：内容（文本/数据/表格）与目标格式（会议模板类名，如 IEEEtran、acmart、NeurIPS style）。
- 可参考 `templates/latex-section.tex.template`。

## 步骤（/paper-latex）

1. 生成可编译的 LaTeX 片段；优先 `booktabs` 表格、`algorithmic`/`algorithm2e` 伪代码、`amsmath` 公式。
2. 使用前核对宏包是否与目标模板兼容。
3. 修改/调试时，只改用户指定的部分，保留其余内容。

## 步骤（/paper-word-helper）

1. 输出结构化 Markdown（标题层级、表格、公式说明），方便用户粘贴进 Word 后套用样式。
2. 公式用 LaTeX 内联写 + 文字说明，便于在 Word 中转换。

## 步骤（/paper-format）

1. 依据目标会议/期刊官方 Author Kit 的模板要求逐项检查：字体、字号、边距、标题、作者、摘要、参考文献样式。
2. 输出“不合规项 → 修改建议”清单；无法确认的规范标注【待验证】并附官方文档链接。

## 输出模板

`/paper-latex`：

```latex
% 可直接放入目标模板的片段
\begin{table}[t]
  \centering
  \caption{...}
  \label{tab:...}
  \begin{tabular}{lcc}
    \toprule
    ...
    \bottomrule
  \end{tabular}
\end{table}
```

`/paper-format`：

```markdown
## 格式检查清单
| 检查项 | 当前 | 要求 | 是否合规 |
| --- | --- | --- | --- |
```

## 安全约束

- 不伪造实验数据填表；表格数据须由用户提供或注明来源。
- 模板规范以官方 Author Kit 为准，不臆造。

## 下一步引导

`/paper-latex` → `/paper-format` → 投稿；`/paper-word-helper` → 手动套用 Word 样式。
