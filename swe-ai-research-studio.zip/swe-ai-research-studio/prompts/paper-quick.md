# /paper-quick — 论文快速粗读筛选

## 用途

用最短时间判断一篇论文是否值得精读：价值判断、一句话贡献、是否相关。

## 输入

- 必填：论文全文/摘要/链接，或已检索到的文献卡片。
- 本地 PDF 可先用 `scripts/extract_pdf.py <file> --pages 1-3` 提取开头章节。

## 步骤

1. 只读标题、摘要、引言第一段、方法第一段、结论与图表标题。
2. 提取：研究问题、方法类型、主要结果、与用户方向的匹配度。
3. 给出价值判断（值得精读 / 泛读 / 跳过），并说明理由。

## 输出模板

```markdown
---
title: <标题>
type: paper-quick
source: <arXiv/DOI>
created: <YYYY-MM-DD>
status: draft
verified: partial
---

# <标题> · 快速粗读

## 一句话贡献
## 研究问题
## 方法类型
## 主要结果
## 与我的方向匹配度（高/中/低 + 理由）
## 价值判断
- [ ] 值得精读
- [ ] 泛读即可
- [ ] 跳过
## 推荐下一步：/paper-deep
```

## 安全约束

- 结论必须来自论文原文；若只看了摘要，标注“基于摘要初判，结论待全文核对”。

## 下一步引导

`/paper-quick` → `/paper-deep` / `/paper-translate` / `/paper-code-map`。
