# /paper-deep /paper-qa — 深度精读与论文问答

本指令覆盖 `/paper-deep`（精读笔记）与 `/paper-qa`（上下文问答）。

## 用途

- `/paper-deep`：产出固定结构的深度精读笔记：动机、RQ、方法、trade-off、实验、limitation、未来方向。
- `/paper-qa`：在给定论文上下文内回答科研问题、组会提问、复试提问。

## 输入

- 必填：论文全文（本地 PDF 或链接）。本地 PDF 用 `scripts/extract_pdf.py <file>` 提取文本。
- 长论文按章节分块精读，每块标注 chunk 标记，最后合并。

## 步骤（/paper-deep）

1. 完整阅读引言、方法、实验、讨论、结论。
2. 按 `templates/paper-notes.md.template` 填表；关键数字注明来自论文的哪张表/图。
3. 无法从原文确认的内容标注【待验证】或【论文未说明】。

## 步骤（/paper-qa）

1. 先定位问题涉及的章节与段落。
2. 用“问题 → 论文原文依据 → 我的解释”三段式回答。
3. 论文未覆盖时明确说“论文未讨论”，并给出合理的进一步阅读建议，不编造。

## 输出模板

`/paper-deep` 直接套用 `templates/paper-notes.md.template`。

`/paper-qa` 输出：

```markdown
## Q: <问题>
**论文原文依据**：<引用关键句，注明章节>
**解释**：...
**延伸**：<可选，推荐补充阅读>
```

## 安全约束

- 不曲解原文，不替论文补写其未给出的结论。
- 关键数据、公式编号、图/表编号需与原文一致。

## 下一步引导

`/paper-deep` → `/note-gen` / `/paper-code-map` / `/paper-reproduce`；`/paper-qa` → `/note-review`。
