# /lit-search /lit-download /bib-auto /lit-sort — 文献检索 & 引用模块

本指令覆盖四个子命令：检索（`/lit-search`）、下载链接（`/lit-download`）、BibTeX（`/bib-auto`）、批量整理（`/lit-sort`）。执行前先确认当前调用的是哪一个。

## 用途

- `/lit-search`：按关键词/标题/作者检索 arXiv 与会议论文，返回摘要、链接、BibTeX。
- `/lit-download`：给定论文，查找官方 PDF / arXiv / publisher / 作者主页下载链接。
- `/bib-auto`：给定论文或引用文本，生成、校验、格式化 BibTeX，支持期刊/会议风格。
- `/lit-sort`：批量整理文献，归类、标注主题、生成文献综述大纲。

## 输入

- 必填：检索关键词 / 论文标题 / DOI / arXiv 编号 / 引用文本 中的至少一项。
- 可选：目标会议或方向、时间范围、返回条数。
- 若输入不足，先向用户确认，不臆造检索结果。

## 步骤

1. 解析输入类型（关键词 / 标题 / arXiv 号 / DOI）。
2. 调用 `web_search` 检索；arXiv 优先使用官方 API（可运行 `scripts/arxiv_meta_fetch.py <query> --bib`）。
3. 对每条结果核对标题、作者、年份、期刊/会议、链接，剔除无法核验的来源。
4. 按对应子命令输出（见下）。

### /lit-search 输出

每条文献一张卡片，套用 `templates/lit-card.md.template`：

```markdown
## <标题>
- **作者**：…
- **年份 / 会议或期刊**：…
- **arXiv / DOI**：…
- **链接**：…
- **一句话贡献**：…
- **摘要**：…
```bibtex
@...
```

### /lit-download 输出

```markdown
| 来源 | 类型 | 链接 | 备注（是否需机构订阅） |
| --- | --- | --- | --- |
| arXiv | PDF | https://arxiv.org/pdf/xxxx.xxxxx | 免费 |
| Publisher | DOI | https://doi.org/... | 可能需订阅 |
| 作者主页 | PDF | ... | 视作者公开情况 |
```

无法确认可下载时标注【待验证】，并说明替代渠道（如机构图书馆、预印本镜像）。

### /bib-auto 输出

1. 生成条目：优先用 `scripts/arxiv_meta_fetch.py <id> --bib`，或按 `templates/bib-standard.bib.template` 手工构造。
2. 校验字段完整性（author/title/journal/booktitle/year 等必需字段）。
3. 统一风格：条目类型小写、字段名小写、作者用 `and` 连接、月份规范。
4. 可运行 `scripts/bib_cleaner.py refs.bib --check` 做自动化校验。
5. 输出 BibTeX 代码块，并注明每条来源与校验结论。

### /lit-sort 输出

```markdown
# 文献整理：<主题>

## 归类结果
| 子主题 | 论文 | 核心贡献 |
| --- | --- | --- |
| ... | [标题](链接) | ... |

## 综述大纲
1. 背景与问题定义
2. 方法谱系（分类）
3. 代表工作对比
4. 未解决问题与趋势
```

## 安全约束

- 不伪造文献、链接、DOI、arXiv 号；无法核验一律标【待验证】。
- 检索失败或结果为空时如实说明，不编造结果。
- 综述大纲只做结构梳理，不代替用户形成最终结论。

## 下一步引导

`/lit-search` → `/paper-quick`（筛选）→ `/paper-deep`（精读）→ `/note-gen`；`/lit-sort` → `/paper-outline`。
