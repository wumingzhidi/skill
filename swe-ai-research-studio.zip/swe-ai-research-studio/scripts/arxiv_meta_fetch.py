#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""查询 arXiv API，返回论文元数据并可生成 BibTeX。供 /lit-search、/bib-auto 使用。

用法:
    python arxiv_meta_fetch.py 1706.03762
    python arxiv_meta_fetch.py "attention is all you need"
    python arxiv_meta_fetch.py 1706.03762 --bib
    python arxiv_meta_fetch.py "software testing" --max 5 --json
"""
import argparse
import json
import re
import sys
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

API = "http://export.arxiv.org/api/query?search_query={q}&start=0&max_results={max}&sortBy=relevance"
NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
}


def _clean(tag):
    return tag.split("}")[-1]


def query(term, max_results=5):
    q = urllib.parse.quote(term)
    url = API.format(q=q, max=max_results)
    with urllib.request.urlopen(url, timeout=30) as resp:
        data = resp.read().decode("utf-8")
    root = ET.fromstring(data)
    results = []
    for e in root.iter():
        if _clean(e.tag) != "entry":
            continue

        def g(tag):
            node = e.find(f"atom:{tag}", NS)
            return node.text.strip() if node is not None and node.text else ""

        authors = []
        for a in e.findall("atom:author", NS):
            name = a.find("atom:name", NS)
            if name is not None and name.text:
                authors.append(name.text.strip())
        cats = [c.get("term") for c in e.findall("atom:category", NS)]
        link = e.find("atom:id", NS).text.strip()
        results.append({
            "title": re.sub(r"\s+", " ", g("title")),
            "authors": authors,
            "summary": re.sub(r"\s+", " ", g("summary")),
            "published": g("published")[:10],
            "updated": g("updated")[:10],
            "arxiv_id": link.rsplit("/abs/", 1)[-1],
            "url": link,
            "categories": cats,
            "doi": g("doi"),
            "comment": g("comment"),
            "journal_ref": g("journal_ref"),
        })
    return results


def bibtex(meta):
    first = meta["authors"][0].split()[-1] if meta["authors"] else "unknown"
    year = meta["published"][:4] or "????"
    key = f"{first.lower()}{year}{meta['arxiv_id'].split('.')[0]}"
    author = " and ".join(meta["authors"])
    title = meta["title"].replace("{", "").replace("}", "")
    primary = meta["categories"][0] if meta["categories"] else ""
    return (
        "@misc{" + key + ",\n"
        f"  title         = {{{title}}},\n"
        f"  author        = {{{author}}},\n"
        f"  year          = {year},\n"
        f"  eprint        = {{{meta['arxiv_id']}}},\n"
        f"  archivePrefix = {{arXiv}},\n"
        f"  primaryClass  = {{{primary}}},\n"
        "}\n"
    )


def main():
    ap = argparse.ArgumentParser(description="查询 arXiv 并生成 BibTeX")
    ap.add_argument("term")
    ap.add_argument("--max", type=int, default=5)
    ap.add_argument("--bib", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    try:
        results = query(args.term, args.max)
    except Exception as exc:
        print(f"查询失败：{exc}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return

    for r in results:
        print(f"标题: {r['title']}")
        print(f"作者: {', '.join(r['authors'])}")
        print(f"arXiv: {r['arxiv_id']}  分类: {', '.join(r['categories'])}")
        print(f"日期: {r['published']}  DOI: {r['doi'] or '无'}")
        print(f"链接: {r['url']}")
        print(f"摘要: {r['summary'][:300]}")
        print("-" * 60)
        if args.bib:
            print(bibtex(r))


if __name__ == "__main__":
    main()
