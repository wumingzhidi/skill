#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 PDF 提取纯文本，供 /paper-quick、/paper-deep、/paper-translate 等子命令使用。

用法:
    python extract_pdf.py paper.pdf                  # 全文输出到 stdout
    python extract_pdf.py paper.pdf --pages 1-5      # 指定页码范围（1-based）
    python extract_pdf.py paper.pdf --out out.txt    # 写入文件
    python extract_pdf.py paper.pdf --json           # 按页 JSON 输出

依赖（任选其一，按优先级）: pypdf / PyPDF2 / pdfplumber
"""
import argparse
import json
import sys


def _backend():
    for name in ("pypdf", "PyPDF2", "pdfplumber"):
        try:
            __import__(name)
            return name
        except Exception:
            continue
    return None


def _parse_pages(spec):
    """解析 '1-5' 或 '1,3,5' 或 'all'，返回 1-based 页码列表；空列表表示全部。"""
    if not spec or spec.strip().lower() == "all":
        return []
    pages = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            pages.update(range(int(a), int(b) + 1))
        else:
            pages.add(int(part))
    return sorted(pages)


def extract(path, pages_spec=None):
    backend = _backend()
    if backend is None:
        raise RuntimeError("未找到 PDF 解析库。请安装：pip install pypdf（或 PyPDF2 / pdfplumber）")
    pages = _parse_pages(pages_spec)

    if backend in ("pypdf", "PyPDF2"):
        if backend == "pypdf":
            from pypdf import PdfReader
        else:
            from PyPDF2 import PdfReader
        reader = PdfReader(path)
        n = len(reader.pages)
        idx = [p - 1 for p in pages] if pages else list(range(n))
        out = []
        for i in idx:
            if 0 <= i < n:
                out.append((i + 1, reader.pages[i].extract_text() or ""))
        return out

    import pdfplumber
    with pdfplumber.open(path) as pdf:
        n = len(pdf.pages)
        idx = [p - 1 for p in pages] if pages else list(range(n))
        out = []
        for i in idx:
            if 0 <= i < n:
                out.append((i + 1, pdf.pages[i].extract_text() or ""))
        return out


def main():
    ap = argparse.ArgumentParser(description="提取 PDF 文本")
    ap.add_argument("pdf")
    ap.add_argument("--pages", help="页码范围，如 1-5 或 1,3,5")
    ap.add_argument("--out", help="输出文本文件路径")
    ap.add_argument("--json", action="store_true", help="按页 JSON 输出")
    args = ap.parse_args()

    try:
        pages = extract(args.pdf, args.pages)
    except Exception as exc:
        print(f"提取失败：{exc}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        payload = {"file": args.pdf, "pages": [{"page": p, "text": t} for p, t in pages]}
        text = json.dumps(payload, ensure_ascii=False, indent=2)
    else:
        text = "\n\n".join(f"--- 第 {p} 页 ---\n{t}" for p, t in pages)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"已写入 {args.out}")
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
