#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""批量导出/合并 Markdown 科研笔记。供 /note-merge 使用。

用法:
    python export_markdown.py --dir notes/ --out merged.md
    python export_markdown.py a.md b.md --out merged.md
    python export_markdown.py --dir notes/ --out merged.md --toc
"""
import argparse
import os
import re
import sys

TITLE_RE = re.compile(r"^#\s+(.+)$", re.M)


def read_note(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def extract_title(text, path):
    m = TITLE_RE.search(text)
    if m:
        return m.group(1).strip()
    return os.path.splitext(os.path.basename(path))[0]


def strip_frontmatter(text):
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            return parts[2].lstrip("\n")
    return text


def merge(files, toc=False):
    sections = []
    for path in files:
        text = read_note(path)
        sections.append((extract_title(text, path), path, strip_frontmatter(text).strip()))

    out = ["# 笔记合并", ""]
    if toc:
        out.append("## 目录")
        for i, (title, path, _) in enumerate(sections, 1):
            out.append(f"{i}. {title}（{os.path.basename(path)}）")
        out.append("")
    for i, (title, path, body) in enumerate(sections, 1):
        out.append("---")
        out.append("")
        out.append(f"## {i}. {title}")
        out.append("")
        out.append(f"> 来源：{os.path.basename(path)}")
        out.append("")
        out.append(body)
        out.append("")
    return "\n".join(out)


def collect(args):
    files = []
    if args.dir and os.path.isdir(args.dir):
        files.extend(
            os.path.join(args.dir, fn)
            for fn in sorted(os.listdir(args.dir))
            if fn.endswith(".md")
        )
    files.extend(args.files)
    seen = set()
    uniq = []
    for f in files:
        key = os.path.abspath(f)
        if key not in seen and os.path.isfile(f):
            seen.add(key)
            uniq.append(f)
    return uniq


def main():
    ap = argparse.ArgumentParser(description="合并 Markdown 科研笔记")
    ap.add_argument("files", nargs="*")
    ap.add_argument("--dir", help="目录，合并其中所有 .md")
    ap.add_argument("--out", required=True, help="输出文件")
    ap.add_argument("--toc", action="store_true", help="生成目录")
    args = ap.parse_args()

    files = collect(args)
    if not files:
        print("没有找到可合并的 .md 文件", file=sys.stderr)
        sys.exit(1)

    with open(args.out, "w", encoding="utf-8") as f:
        f.write(merge(files, args.toc))
    print(f"已合并 {len(files)} 个文件到 {args.out}")


if __name__ == "__main__":
    main()
