#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BibTeX 清洗/校验/去重工具。供 /bib-auto 使用。

用法:
    python bib_cleaner.py refs.bib                     # 原地规范化并校验
    python bib_cleaner.py refs.bib --out clean.bib     # 输出到新文件
    python bib_cleaner.py refs.bib --check             # 仅校验不修改
    python bib_cleaner.py a.bib b.bib --merge out.bib  # 合并去重后写出
"""
import argparse
import re
import sys

REQUIRED = {
    "article": ["author", "title", "journal", "year"],
    "inproceedings": ["author", "title", "booktitle", "year"],
    "incollection": ["author", "title", "booktitle", "year"],
    "phdthesis": ["author", "title", "school", "year"],
    "mastersthesis": ["author", "title", "school", "year"],
    "techreport": ["author", "title", "institution", "year"],
    "book": ["title", "publisher", "year"],
    "misc": ["title"],
}

SKIP_TYPES = {"comment", "preamble", "string"}

FIELD_RE = re.compile(r"([A-Za-z][A-Za-z0-9_\-]*)\s*=\s*(\{.*?\}|\".*?\")\s*,?", re.S)


def parse_entries(text):
    entries = []
    depth = 0
    buf = []
    for line in text.splitlines():
        if depth == 0 and line.lstrip().startswith("@") and buf:
            entries.append("\n".join(buf))
            buf = []
        buf.append(line)
        depth += line.count("{") - line.count("}")
    if buf:
        entries.append("\n".join(buf))
    return [b for b in entries if b.strip()]


def parse_one(block):
    m = re.match(r"@\s*(\w+)\s*\{\s*([^,\s]+)\s*,", block, re.S)
    if not m:
        return None
    typ = m.group(1).lower()
    key = m.group(2)
    fields = []
    for name, raw in FIELD_RE.findall(block[m.end():]):
        val = raw.strip()
        if (val.startswith("{") and val.endswith("}")) or (val.startswith('"') and val.endswith('"')):
            val = val[1:-1]
        fields.append((name.lower(), val.strip()))
    return {"type": typ, "key": key, "fields": fields}


def gen_key(entry):
    author = ""
    title = ""
    year = ""
    for name, val in entry["fields"]:
        if name == "author" and not author and val:
            author = val.split(" and ")[0].split(",")[0].split()[-1]
        elif name == "title" and not title:
            title = re.sub(r"[^A-Za-z0-9]+", "", val)[:12]
        elif name == "year" and not year:
            m = re.search(r"\d{4}", val)
            year = m.group(0) if m else ""
    if author and year:
        return f"{author.lower()}{year}{title.lower()}"
    return None


def render(entry):
    lines = [f"@{entry['type']}{{{entry['key']},"]
    for name, val in entry["fields"]:
        lines.append(f"  {name:<14}= {{{val}}},")
    lines.append("}")
    return "\n".join(lines)


def process(text):
    out = []
    seen_keys = set()
    seen_titles = set()
    warnings = []
    for block in parse_entries(text):
        entry = parse_one(block)
        if entry is None:
            continue
        if entry["type"] in SKIP_TYPES:
            continue

        title = next((v for n, v in entry["fields"] if n == "title"), "").strip().lower()
        if title and title in seen_titles:
            warnings.append(f"跳过重复条目（标题重复）：{entry['key']}")
            continue
        if title:
            seen_titles.add(title)

        key = entry["key"].strip()
        if not key or key.isdigit() or " " in key:
            new_key = gen_key(entry)
            key = new_key or f"ref{len(out) + 1}"
        lkey = key.lower()
        if lkey in seen_keys:
            key = f"{key}{len(out) + 1}"
            lkey = key.lower()
        seen_keys.add(lkey)
        entry["key"] = key

        names = {n for n, _ in entry["fields"]}
        missing = [r for r in REQUIRED.get(entry["type"], []) if r not in names]
        if missing:
            warnings.append(f"[{entry['key']}] 缺少必需字段：{', '.join(missing)}")
        out.append(entry)
    return out, warnings


def main():
    ap = argparse.ArgumentParser(description="清洗/校验 BibTeX")
    ap.add_argument("files", nargs="+")
    ap.add_argument("--out", help="输出到文件（单输入时默认为原地覆盖）")
    ap.add_argument("--merge", help="合并多个输入并写到该文件")
    ap.add_argument("--check", action="store_true", help="仅校验不修改")
    args = ap.parse_args()

    text = "\n".join(open(f, encoding="utf-8").read() for f in args.files)
    entries, warnings = process(text)

    if args.check:
        print(f"共解析 {len(entries)} 个条目")
        for w in warnings:
            print(w)
        sys.exit(1 if warnings else 0)

    rendered = "\n\n".join(render(e) for e in entries) + "\n"
    if args.merge:
        out_path = args.merge
    elif args.out:
        out_path = args.out
    else:
        out_path = args.files[0]

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(rendered)
    print(f"已写入 {out_path}（{len(entries)} 个条目）")
    for w in warnings:
        print(w)


if __name__ == "__main__":
    main()
